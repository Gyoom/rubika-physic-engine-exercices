#ifndef PARTICLE_H
#define PARTICLE_H

// TODO:

#endif